# How to install (DEFAULT or BASIC USAGE)
	* git clone https://github.com/teamsyntaxid/bot-ig.git
	* cd bot-ig
	* unzip node_modules.zip
	* node index.js
	* Then select the tool you want to use!
<br/>

# For PC/Laptop ONLY:
	* Download GIT for Windows	(https://git-scm.com/download/) *Choose WIN & 32bit/64bit
	* Download NodeJS 			(https://nodejs.org/en/download/) *Choose .msi & 32bit/64bit
	* INSTALL GIT for Windows & NodeJS
	* Download File on Github (https://github.com/teamsyntaxid/bot-ig.git)
	* Extract File bot-ig-master and enter the folder
	* Right Click on Mouse, Then Select "Git Bash Here" (Make sure you are in the bot-ig folder!!!)
	* Then type: unzip node_modules.zip
	* To View The Contents Of a folder in bash, type: "ls" (without "")
	* To Run The Program in bash, type: "node index.js" (without "")
	* Then select the tool you want to use!
<br/>

# For TERMUX ONLY:
	* Install Termux (PlayStore)
	* Open Termux and Wait for Automatic Install of Termux.
	* pkg install git
	* pkg install nodejs
	* git clone https://github.com/teamsyntaxid/bot-ig.git
	* cd bot-ig
	* unzip node_modules.zip
	* ls
	* node index.js
	* Then select the tool you want to use!
<br/>

# INFORMATION:
	* dellallphoto		"Delete All Post IG"			(WORK & TESTED)
	* fah				"SELECTED WITH HASTAG IG"		(WORK & TESTED)
	* fftauto			"SELECTED WITH TARGET IG"		(WORK & TESTED)
	* flaauto			"SELECTED WITH LOCATION IG"		(WORK & TESTED)
	* flmauto			"SELECTED WITH MEDIA IG"		(WORK & TESTED)
	* unfollall			"UNFOLOW ALL FOLLOWING IG"		(WORK & TESTED)
	* unfollnotfollback	"UNFOLLOW NOT FOLLOWBACK IG"	(WORK & TESTED)
	* botlike			"LIKE/LOVE TIMELINE IG"			(WORK & TESTED)
	* botlike2			"LIKE/LOVE TIMELINE IG"			(WORK & TESTED)
<br/>

# WARNING
	"Use tools at your own risk!!!"
	"Use this Tool for personal use, not for sale!!!"
	"Make sure your account is not in private to use this tool!!!"
<br/>

# UPDATE
	1. Fix Error No Detect Followers Target
    2. Input Target/delay Manual (ITTYW)
    3. + Improvements In Display Program
<br/>

# SPECIAL THANKS TO:
	* Code by Ccocot (ccocot@bc0de.net)
	* Fixing and Testing by Putu Syntax
	* SGB TEAM REBORN
	* BC0DE.NET | NAONLAH.NET - WingKocoli
